import javax.swing.JPanel;

import java.awt.Color;

import javax.swing.JFrame;

public class NewGame{

	public static void main(String args[])
	{
		//CollisionMapGenerator cmp = new CollisionMapGenerator("collisionMapTest.png");
		//System.out.println(cmp.getRGBArrayString());
		//Ignore the CollisionMapGenerator and MyPixelColor classes, they don't work completely yet.
		
		GameWindow gameWindow = new GameWindow();
	}
	
	
}
