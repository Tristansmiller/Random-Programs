import java.util.*;
import java.awt.*;
import java.awt.event.*;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;


public class Core {

	public static void main(String args[]) {
		CalcInterface gui = new CalcInterface();
	}
}
